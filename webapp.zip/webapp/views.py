
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect, HttpResponse

#from .forms import NameForm, Login, AccForm, AccFormDep
#from .models import Usuario, Conta, Dependente, DependenteConta

#from django.contrib.auth import authenticate, login as auth_login

#from django.contrib.auth import logout
#from django.contrib.auth.models import User

def index(request):

	return render(request, 'webapp/add_tvshow.html')

def showlist():
	pass