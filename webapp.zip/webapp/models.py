from django.db import models

# Create your models here.

class TvShowModel(models.Model):

	tvs_id = models.CharField(max_length=100, primary_key=True)
	tvs_name = models.CharField(max_length=100)
	tvs_name_br = models.CharField(max_length=100)
	tvs_genre = models.FloatField()
	tvs_language = models.NullBooleanField()
	tvs_status = models.CharField(max_length=100)
	tvs_runtime = models.FloatField()
	tvs_schedule = models.DateField()
	tvs_rating = models.CharField(max_length=100)
	tvs_timezone = models.CharField(max_length=100)
	tvs_imdb_id = models.CharField(max_length=100)
	tvs_img_m_url = models.CharField(max_length=100)
	tvs_summary = models.TextField(max_length=100)
	tvs_summary_br = models.TextField(max_length=100)
	tvs_likes = models.FloatField()

class TvShowEpModel(models.Model):

	tvs_id_pk = models.OneToOneField(TvShowModel)
	tve_name = models.CharField(max_length=100)
	tve_season = models.CharField(max_length=100)
	tve_airdate = models.CharField(max_length=100)
	tve_airtime = models.CharField(max_length=100)
	tve_img_ep = models.CharField(max_length=100)
	tve_runtime = models.FloatField()
	tve_summary = models.TextField(max_length=100)
	tve_summary_br = models.TextField(max_length=100)
